.on_load = function (ns) {
    message('knitr/a')
}

box::export()
