before = box::name()
box::use(./a)
after = box::name()

before; after
