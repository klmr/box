devtools::load_all(quiet = TRUE)
cat(paste0(box:::base_path(environment()), '\n'))
