box::use(./a)
