.on_load = function (ns) {
    cat('a/b/d/__init__.r\n')
}

box::export()
