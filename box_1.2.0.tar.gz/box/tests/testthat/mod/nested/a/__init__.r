.on_load = function (ns) {
    cat('a/__init__.r\n')
}

#' @export
which = function () 'nested/a'
