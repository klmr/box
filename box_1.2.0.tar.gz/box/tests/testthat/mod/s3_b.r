box::use(./s3)

#' @export
test = s3$test
