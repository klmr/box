#' @export
box::use(b = ./cyclic_b)

#' @export
name = 'a'

#' @export
b_name = function () {
    b$name
}
