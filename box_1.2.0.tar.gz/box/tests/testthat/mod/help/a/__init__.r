#' A test module
'.__module__.'

#' @export
box::use(./b)
