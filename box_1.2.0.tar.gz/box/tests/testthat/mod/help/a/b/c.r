#' Test module
'.__module__.'

#' Test function
#'
#' \code{d()} does nothing.
#' @param x unused
#' @export
d = function (x) NULL
