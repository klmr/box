box::use(./a[...])

double = function (x) c(x, x)

indirect_counter = function () get_counter()

.hidden = 'hidden'

box::export()
