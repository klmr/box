#' @export
box::use(a = ./cyclic_a)

#' @export
name = 'b'

#' @export
a_name = function () {
    a$name
}
