box::use(../seq[...])
